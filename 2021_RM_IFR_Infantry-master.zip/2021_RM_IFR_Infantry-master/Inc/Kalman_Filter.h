#ifndef _KALMAN_FILTER_H
#define _KALMAN_FILTER_H
#include "main.h"


float Kalman_Filter(float Accel,float Gyro);
float Filter_one(float data,float Kp);



#endif
